# Schema

This directory contains JSON schema files, compiled from `../schema-template`. See the README there for more information.
